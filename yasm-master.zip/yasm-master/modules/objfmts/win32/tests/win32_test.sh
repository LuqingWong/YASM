#! /bin/sh
${srcdir}/out_test.sh win32_test modules/objfmts/win32/tests "win32 objfmt" "-f win32" ".obj"
exit $?
