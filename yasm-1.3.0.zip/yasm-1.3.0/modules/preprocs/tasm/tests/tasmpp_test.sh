#! /bin/sh
${srcdir}/out_test.sh tasmpp_test modules/preprocs/tasm/tests "tasm preproc" "-f bin -p tasm" ""
exit $?
